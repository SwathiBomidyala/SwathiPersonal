1. Pull latest resources from 'shared-workview-res'
2. Copy 'strings.json' file into project (replace if needed)
3. Run app
4. In loger you will see path of files. ('Files generated!' path)
5. if tests required you should replace 'JsonLocalization folder' with new generated files 
and 'OriginalLocalization' with exist files from WorkView (localization strings files)
5.1 Run testExample()
6. Copy new files into WorkView

//Check workview missing keys
1. Open terminal (WorkView folder)
2. Run ./localization_validator.sh 

