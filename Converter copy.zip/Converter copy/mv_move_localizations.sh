#!/bin/bash

# Source and destination paths
SOURCE_DIR="/Users/swathibomidyala/Converter/Converter/NewTranslations/Converted Files"
DEST_DIR="/Users/swathibomidyala/ios-myverint-app/MyVerint/MyVerint/Resources"

echo "Starting localization replacement..."

for file in "$SOURCE_DIR"/*_new.*; do
    [ -e "$file" ] || continue

    filename=$(basename "$file")

    # Extract language code (de, ja, zh, en, etc.)
    lang=${filename%%_*}

    target_lproj=""

    # Find matching .lproj folder by first part
    for dir in "$DEST_DIR"/*.lproj; do
        folder=$(basename "$dir" .lproj)
        base_lang=${folder%%-*}

        if [ "$base_lang" == "$lang" ]; then
            target_lproj="$dir"
            break
        fi
    done

    if [ -z "$target_lproj" ]; then
        echo "⚠️  No matching lproj folder for language: $lang"
        continue
    fi

    # Decide target filename
    if [[ "$filename" == *.strings ]]; then
        target="$target_lproj/Localizable.strings"
    elif [[ "$filename" == *.stringsdict ]]; then
        target="$target_lproj/Localizable.stringsdict"
    else
        continue
    fi

    echo "Replacing $target"
    cp -f "$file" "$target"
done

echo "Localization update completed."
