//
//  Validator.swift
//  Validator
//
//  Created by Pavlo Khanukov on 24/08/2022.
//  Copyright © 2022 Levi Khanukov. All rights reserved.
//

import XCTest

typealias ValidationResult = (missing: Set<String>, differences: Set<String>)

class Validator: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    
    let listOfLanguages = ["en", "de", "es", "fr", "ja", "nl", "pt", "ru", "zh"]

    func testSt() throws {
        let int: Float = 1
        let string = String(format: "%1$@%2$.2f", "$", int)
        print(string)
        print("done")
    }
    
    func testExample() throws {
        var setOfMissingKeys: Set<String> = []
        var setOfDifferentValues: Set<String> = []
        var missingPerLng: [String: Set<String>] = [:]
        var differentPerLng: [String: Set<String>] = [:]
        
        for language in listOfLanguages {
            let result = runValidation(for: language, newLanguage: language)
            
            if result.missing.isEmpty == false {
                missingPerLng[language] = result.missing
            }
            
            if result.differences.isEmpty == false {
                differentPerLng[language] = result.differences
            }
/* un/comment if you need different sorting of keys (in log)  */
 /*
            if setOfMissingKeys.isEmpty {
                setOfMissingKeys.formUnion(result.missing)
            } else {
                var lngMissingKeys = result.missing
                lngMissingKeys.subtract(setOfMissingKeys)
                missingPerLng[language] = lngMissingKeys
            }
            
            if setOfDifferentValues.isEmpty {
                setOfDifferentValues.formUnion(result.differences)
            } else {
                var lngDifferentValues = result.differences
                lngDifferentValues.subtract(setOfDifferentValues)
                differentPerLng[language] = lngDifferentValues
            }
  */
        }
        
        if setOfMissingKeys.isEmpty == false {
            print("\nMissing in all languages")
            for setOfMissingKey in setOfMissingKeys {
                print(setOfMissingKey)
            }
            
            print("total:", setOfMissingKeys.count)
        }
        
        for pair: String in missingPerLng.keys {
            let values = missingPerLng[pair] ?? []
            guard values.isEmpty == false else { continue }
            print("\nMissing key for languages:", pair)
            for value in values.sorted() {
                print(value)
            }
            
            print("total:", values.count)
        }
        
        if setOfDifferentValues.isEmpty == false {
            print("\nDiffrences in all languages")
            for setOfMissingKey in setOfDifferentValues {
                print(setOfMissingKey)
            }
            
            print("total:", setOfDifferentValues.count)
        }
        
        for pair: String in differentPerLng.keys {
            let values = differentPerLng[pair] ?? []
            guard values.isEmpty == false else { continue }
            print("\nDiffrence key for languages:", pair)
            for value in values.sorted() {
                print(value)
            }
            
            print("total:", values.count)
        }
        
        XCTAssert(setOfMissingKeys.isEmpty && missingPerLng.isEmpty && setOfDifferentValues.isEmpty && differentPerLng.isEmpty, "See logs")
    }
    
    func runValidation(for origLanguage: String, newLanguage: String) -> ValidationResult {
        let originalFile = getFile("\(origLanguage)_original")
        let newFile = getFile("\(newLanguage)_new")
        
        guard let originalDict = originalFile else {
            print("failed to get original \(origLanguage) strings")
            return ([], [])
        }
        
        guard var newDict = newFile else {
            print("failed to get new strings", newLanguage)
            return ([], [])
        }
        
        var listOfMissingValues: Set<String> = []
        var listOfDifferentValues: Set<String> = []
        
        for key: String in originalDict.keys {
            guard newDict.keys.contains(key) else {
                listOfMissingValues.insert(key)
                continue
            }
            
            let originalValue = originalDict[key] ?? ""
            let newValue = newDict[key] ?? ""
            if originalValue != newValue  {
                let replaceString = ["%@" : "%@" , "$@" : "%@"]
                let toInt = ["%d" : "%ld" ,
                             "$ld" :"%ld",
                             "%02ld": "%02ld"]
                let toInt2 = ["$.2f": "%.2f", "%.2f" : "%.2f"]
                
                for dict in [replaceString, toInt, toInt2] {
                    let pair = dict.first(where: { key, value in
                        if newValue.contains(key) {
                            return true
                        }
                        
                        return false
                    })
                    
                    guard let value = pair?.value else { continue }
                    if originalValue.contains(value) == false {
                        let difference = String(format: "\t%@\n\tOriginal: %@\n\tNew: %@\n", key, originalValue, newValue)
                        listOfDifferentValues.insert(difference)
                    }
                }
            }
            
            newDict.removeValue(forKey: key)
        }
        
        listOfMissingValues.remove("")
        
        if newDict.isEmpty == false {
            print("\nNew keys in language", newLanguage)
            for key in newDict.keys.sorted() {
                print("\t", key)
            }
        }
        
        return (listOfMissingValues, listOfDifferentValues)
    }
    
    func getFile(_ name: String) -> [String: String]?  {
        let bundle = Bundle(for: Validator.self)
        guard let path = bundle.path(forResource: name, ofType: "strings") else {
            XCTFail("no such file with name \(name) in bundle: \(bundle.debugDescription)")
            return nil
        }
        
        return NSDictionary(contentsOf: URL(fileURLWithPath: path)) as? [String: String]
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        measure {
            // Put the code you want to measure the time of here.
        }
    }

}
