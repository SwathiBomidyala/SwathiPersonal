//
//  ViewController.swift
//  Converter
//
//  Created by Levi Khanukov on 25/05/2020.
//  Copyright © 2020 Levi Khanukov. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet var lngCodeField: UITextField! {
        didSet {
            lngCodeField.text = "he"
        }
    }
    
    @IBAction func convertJSON() {
        Convert().create()
    }

    @IBAction func populateLanguage() {
        let lang = lngCodeField.text ?? ""
        Convert().insertTranslationKeys(langCode: lang)
    }
    
    @IBAction func insertNewTranlations() {
        Convert().insertNewTranslationKeys()
    }
    
    @IBAction func createIVATranlations() {
        Convert().createIVA()
    }
    
    @IBAction func createForTranslationTeamSourceFile() {
        Convert().create(asSourceFileForTranslationTeam: true)
    }
}

