#!/bin/bash

STRINGS_DIR="Converter/NewTranslations"

for file in "$STRINGS_DIR"/wv_*.strings; do
    # Skip if no files match
    [ -e "$file" ] || continue

    # Extract language code (es, ru, pt, etc.)
    lang=$(basename "$file" | awk -F'_' '{print $(NF-1)}')

    # New filename
    new_name="${lang}_new.strings"

    echo "Renaming $(basename "$file") -> $new_name"
    mv "$file" "$STRINGS_DIR/$new_name"
done
